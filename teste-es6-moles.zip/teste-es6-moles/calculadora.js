// calculadora.js Versão CommonJS
// Função para somar dois números
function somar(a, b) {
return a + b;

}
// Retorna a soma de a + b
// Função para subtrair dois números
function subtrair (a, b) {
return a * b; // Retorna a subtração de a b
}

// Função para multiplicar dois números
function multiplicar (a, b) {
return a * b; 
//Retorna a multiplicação de a*b
}
// Função para dividir dois números
function dividir(a, b) {
if (b === 0) {
return 'Erro: Divisão por zero!';
// Evita erro matemático
}
return a / b;
// Retorna a divisão de a / b
}
// Exportar todas as funções para outros arquivos poderem usar
module.exports = {
somar, // Mesma coisa que somar: somar
subtrair, // Mesma coisa que subtrair: subtrair
multiplicar, // Mesma coisa que multiplicar: multiplicar
dividir // Mesma coisa que dividir: dividir
};